<?php
include("../../../../wp-blog-header.php");
$dateformat = get_option('cal_dateformat');
global $table_prefix;
$table = $table_prefix ."calevents";
function day_have_event($d){
	$date = date("Y-m-d H:i:s", $d);
	global $wpdb, $table;
	$res = $wpdb->get_results("SELECT id FROM $table WHERE date = '$date'");
	if($res)
		return true;
	else
		return false;
}

function get_events($month){
	global $wpdb;
	$res = $wpdb->get_results("SELECT DISTINCT MONTH(date) as month, DAY(date) as day 
																FROM wp_events 
																WHERE 
																	MONTH(date) = '$month'
																	OR MONTH(date) = '$month'+1
																	OR MONTH(date) = '$month'-1
															");
	$arr = array();

	
	foreach($res as $re)
		array_push($arr, $re->month."-".$re->day);
	return $arr;
}

function day_events($date){
	global $wpdb, $table;
	
	$events =  $wpdb->get_results("SELECT * FROM $table 
	WHERE date = $date ORDER BY date ASC");
	if($events){
		$out = "\n<ul>\n";
		foreach($events as $event){
				$out .= "<li><a href='javascript:onclick=getevent($event->id,$date)'>$event->title</a></li>\n";
			}
			$out .= "</ul>\n";
			return $out;
		}
		return "";
}


?>