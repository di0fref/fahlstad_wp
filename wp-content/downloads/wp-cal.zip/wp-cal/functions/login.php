<?php
include("../../../../wp-blog-header.php");

	$pass = get_option('cal_pass');
	
	if($_POST['pass'] == get_option('cal_password'))
		echo trim("ok");
	else
		echo "Sorry, Wrong Password!";
?>

