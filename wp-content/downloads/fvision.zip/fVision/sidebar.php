	<div id="sidebar">
	<a href="#navigation">Go to navigation</a>
<?php 
	global $wpdb;
	
	if(!is_home())
	{
		$sql = "SELECT * FROM ".$wpdb->posts." ORDER BY post_date DESC LIMIT 5";
		$results = $wpdb->get_results($sql);
		echo "<h2>Recent entries</h2>\n<ul>\n";
		
		foreach($results as $result) {
			echo "<li><a href='".get_permalink($result->ID)."'>$result->post_title</a></li>";
		}
		echo "</ul>";	
	}
	?>
	
<?php 
	if(function_exists('fquick_get'))
		fquick_get();
	else
		echo "<p>You need the <a href='http://www.fahlstad.se/wordpress/plugins/fquick'>fQuick</a> plugin for this theme to work properly</p>";
	?>
			
	</div>

