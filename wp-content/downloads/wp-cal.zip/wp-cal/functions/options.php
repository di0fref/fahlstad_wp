<?php
	add_option('cal_is_private', 'false');
	add_option('cal_week_start', 'monday');
	add_option('cal_password', '');
	add_option('cal_dateformat', 'Y-m-d');
	add_option('cal_where', 'side');
	

if(isset($_POST['cal_update'])){
	update_option('cal_is_private', $_POST['cal_is_private']);
	update_option('cal_week_start', $_POST['week_start']);
	update_option('cal_password', $_POST['cal_password']);
	update_option('cal_dateformat', $_POST['dateformat']);
	update_option('cal_where', $_POST['cal_where']);?>
	
	<div class="updated fade"><p>Options updated.</p></div><?php
}
?>
<div class="wrap">
	<h2>WP-Cal Options</h2>
	
	<form method="post" action="">
	
		<table cellpadding="5" cellspacing="2" class="">
			<tr>
				<td valign="top"><b>Weeks starts on: </b></td>
				<td>
					<input type="radio" name="week_start" value="sunday" <?php if(get_option('cal_week_start') == 'sunday') echo " checked";?> /> Sunday <br />
					<input type="radio" name="week_start" value="monday" <?php if(get_option('cal_week_start') == 'monday') echo " checked";?> /> Monday
				</td>
			</tr>	
			
			<tr>
				<td><b>Calendar is private: </b></td>
				<td>
					<input type="checkbox" value="true" name="cal_is_private"
					<?php if(get_option('cal_is_private') == true) echo "checked='checked'";?> />
				</td>
			</tr>
			<tr>
				<td><b>Today's events on the right: </b></td>
				<td>
					<input type="checkbox" value="side" name="cal_where"
					<?php if(get_option('cal_where') == 'side') echo "checked='checked'";?> />
				</td>
			</tr>
			<tr>
				<td valign="top"><b>Password: </b></td>
					<td><input type="text" name="cal_password" value="<?php echo get_option('cal_password');?>" /> Optional
					</td>
			</tr>
			<tr>
				<td valign="top"><b>Date format: </b></td>
					<td><input type="text" name="dateformat" value="<?php echo get_option('cal_dateformat');?>" /> Output: <b><?php echo date(get_option('cal_dateformat'), time());?></b>
					<p>Default date: Y-m-d. <br /> 
					Check <a href="http://se.php.net/manual/en/function.date.php">PHP date()</a> for date formatting.</p></td>
			</tr>
			
		</table>
	<input type="submit" value="Update options" name="cal_update">
	</form>

</div>