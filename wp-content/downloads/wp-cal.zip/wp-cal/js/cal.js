var baseurl = "/wp-content/plugins/wp-cal";
function cal_init(){
	url = baseurl + "/functions/cal.php";
	$('cal').style.display = 'block';
	if($('error'))
		$('error').style.display = 'none';
	if($('calloginform'))
		Element.remove('calloginform');
	new Ajax.Updater('cal', url, {asynchronous:true});
	get_day(false);
	
}
function reload_cal(date){
	url = baseurl + "/functions/cal.php?date=" + date;
	new Ajax.Updater('cal', url);
}
function get_month(month){
	clear();
	var url = baseurl + "/functions/cal.php?date=" + month;
	new Ajax.Updater('cal', url, {onLoading: function(){loading('cal')}, asynchronous:true});
}
function login(){
	url = baseurl + "/functions/login.php";
	var body = 'pass=' + $F('pass')	
	new Ajax.Request(url, {onComplete: checklogin, method: 'post', postBody: body, asynchronous:true });	
	return false;
}
function checklogin(response){
	var t = trim(response.responseText);
	if(t == "ok"){
		cal_init();
	}
	else{
		$('error').style.display = 'block'
		$('error').innerHTML = response.responseText;
	}
}
function get_day(date){
	$('calext').style.display = 'block';
	
	var url = baseurl + "/functions/day.php?date=" + date;
	new Ajax.Updater('calext', url, {onLoading:function(){loading('calext');}, asynchronous:true});
}

function editevent(id, date){
		var url = baseurl + "/functions/editevent.php?id=" + id + '&date=' + date;
		new Ajax.Updater('calext', url, {onLoading:function(){loading('calext');}, asynchronous:true});
		
				
}
function validate(){
	var title = $F('title');
	var start = $F('start_time');
	var end = $F('end_time');
	$('titleerror').innerHTML = "";
	$('starterror').innerHTML = "";
	$('enderror').innerHTML = "";
	var error = false;
	if(title == ''){
		$('titleerror').innerHTML = "Error: Title can not be empty!"
		error = true;
	}
	if(!start.match('^([0-1][0-9]|[2][0-3]):([0-5][0-9])$')){
		$('starterror').innerHTML = "Error: Wrong format, (hh:mm)!"
		error = true;
	}
	if(!end.match('^([0-1][0-9]|[2][0-3]):([0-5][0-9])$')){
		$('enderror').innerHTML = "Error: Wrong format, (hh:mm)!"
		error = true;
	}
	var s = start.split(':');
	var e = end.split(':');
	
	if( (s[0] > e[0]) || ((s[0] == e[0]) && (s[1] > e[1])) ){
			
			$('enderror').innerHTML = "Error: End time is earlier then start time!"
			error = true;
	}
	if(error == true){
		alert("There are fields which need correction before sending.")
		return false;
	}
	return true;
}
function doedit(){
	if(!validate())
		return false;
	var url = baseurl + "/functions/editevent.php";
	var id = $F('id');
	var date = $F('date');
	var title = $F('title');
	var start_time = $F('start_time');
	var end_time = $F('end_time');
	var description = $('description').value;	
	var body = 	'date=' + date +
							'&id=' + id + 
							'&title=' + title + 
							'&description=' + description + 
							'&start_time=' + start_time + 
							'&end_time=' + end_time +
							'&action=doedit';
							
	new Ajax.Request(url,{	
													method:'post',
													postBody: body,
													onComplete: complete,
													asynchronous:true
		});
		return false;
}
function addevent(date){
	var url = baseurl + "/functions/addevent.php?date=" + date;
	new Ajax.Updater('calext', url, {onLoading:function(){loading('calext');}, asynchronous:true});
	
}
function doadd(){
	if(!validate())
		return false;
	var url = baseurl + "/functions/addevent.php";
	var date = $F('date');
	var title = $F('title');
	var start_time = $F('start_time');
	var end_time = $F('end_time');
	var description = $('description').value;
	var body = 	'date=' + date + 
							'&title=' + title + 
							'&description=' + description + 
							'&start_time=' + start_time + 
							'&end_time=' + end_time + 
							'&action=doadd';
							
	new Ajax.Request(url,{	
													method:'post',
													postBody: body,
													onComplete: complete_add,
													asynchronous:true
		});
}
function complete(response){
	$('msg').innerHTML = response.responseText;
	$('msg').style.display = 'block'
	getevent($F('id'), $F('date'))
	new Effect.Highlight('msg');
	reload_cal($F('date'));
}

function complete_add(response){
	$('msg').innerHTML = response.responseText;
	$('msg').style.display = 'block'
	get_day($F('date'))
	new Effect.Highlight('msg');
	reload_cal($F('date'));
}

function delevent(id, date){
	if(confirm("Do you want to delete this event?")){
		var url = baseurl + "/functions/delevent.php?id=" + id;
		new Ajax.Updater('event-'+ id, url, {
				onComplete:function(){ new Effect.Fade('event-'+ id);reload_cal(date);},
				asynchronous:true});
	}
}
function getevent(id, date){
	var url = baseurl + "/functions/event.php?id=" + id + '&date=' + date;
	new Ajax.Updater('calext', url, {onLoading:function(){loading('calext')}, asynchronous:true});

}
function clear(){
	$('msg').innerHTML = "";
	$('msg').style.display = 'none'
	$('calext').innerHTML = "";
}
function trim(str){
   return str.replace(/^\s*|\s*$/g,"");
}
function loading (div) {
	$(div).innerHTML = "<img src='"+ baseurl +"/images/indicator.gif' />"
}
//Event.observe(window, 'load', cal_init, false);









