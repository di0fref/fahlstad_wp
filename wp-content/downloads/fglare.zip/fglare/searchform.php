<div id="searchdiv">
<form method="get" id="searchform" action="<?php echo get_bloginfo('siteurl');?>">
	<table>
		<tr>
				<td><input type="text" size="15" value="" name="s" id="s" /></td>
				<td><input type="submit" class="submit"  id="searchbutton"  value="Search"/></td>
				<input type="hidden" name="path" value="<?php echo get_bloginfo('siteurl');?>" id="path" />
			</tr>
	</table>
	</form>
	
</div>