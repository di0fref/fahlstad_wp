<?php
include("../../../../wp-blog-header.php");
include( 'functions.php' );

global $wpdb, $table;
if(isset($_GET['id'])){
	$wpdb->query("DELETE FROM $table WHERE id = $_GET[id]");
	echo "<p>Event deleted</p>";
}
?>