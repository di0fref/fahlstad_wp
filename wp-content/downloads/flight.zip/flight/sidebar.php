<div id="sidebar">
  <?php include(TEMPLATEPATH ."/searchform.php")?>
<div id="sidemain">
  <h2>Feeds</h2>
  <ul id="feed">
    <li><a href="<?php bloginfo('rss2_url'); ?>" title="<?php _e('Syndicate this site using RSS'); ?>">RSS Articles</a></li>
  </ul>
	<h2><?php _e("Pages");?></h2>
		<ul><?php wp_list_pages('title_li=');?></ul>
	<h2><?php _e("Categories")?></h2>
		<ul><?php wp_list_cats(); ?></ul>
	
	<h2><?php _e("Monthly Archives") ?></h2>
	<ul><?php wp_get_archives('type=monthly'); ?></ul>
	
	<ul><?php get_links_list(); ?></ul>
	</div>
</div>
