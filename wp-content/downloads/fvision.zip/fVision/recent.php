</div>
<a name="navigation" id="navigation"></a><div id="bottom">
  <div id="bottomcontent">
    <div id="recent">
      <h3>Recent entries</h3>
      <?php
 $posts = get_posts('numberposts=5&offset=1');
 foreach($posts as $post) :
 setup_postdata($post);
 ?>
      <h4><a href="<?php the_permalink(); ?>" id="post-<?php the_ID(); ?>">
        <?php the_title(); ?>
        </a>
        <?php the_time('F dS Y'); ?>
      </h4>
      <?php the_excerpt(); ?>
      <?php endforeach; ?>
    </div>
    <div id="nav">
      <ul>
        <li>
          <h2>Archives</h2>
          <ul>
            <?php wp_get_archives('type=monthly'); ?>
          </ul>
        </li>
        <li>
          <h2>Categories</h2>
          <ul>
            <?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=0'); ?>
          </ul>
        </li>
		<?php if (function_exists('wp_theme_switcher')) { ?>
			<h2><?php _e('Themes'); ?></h2>
				<?php wp_theme_switcher(); }?>

        <li>
          <h2>Meta</h2>
          <ul>
            <?php wp_register(); ?>
            <li><a href="<?php bloginfo('rss2_url'); ?>" title="<?php _e('Syndicate this site using RSS'); ?>">
              <?php _e('<abbr title="Really Simple Syndication">RSS</abbr>'); ?>
              </a></li>
            <li>
              <?php wp_loginout(); ?>
            </li>
            <li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a></li>
            <li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
            <li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
            <li><?php wp_meta(); ?></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</div>
