Usage

All contents published on this site, including pieces of text, themes, 
plugins desktops etc. are limited to personal use. 
Any redistribution such as extraction as PNG files, uploading to a website/forum, 
or using for commercial (adsense is fine) without prior consent from me is prohibited. 
As goes for commercial use of my themes I do expect to get payed for them.

The price for using my themes for commercial use can be found at my services page. 
All themes and plugins downloaded from this site is tested for bugs and errors, 
however you use them at your own risk and Fredrik Fahlstad can not be held 
responsible for any damage themes or plugins may cause.

Use on commercial sites.

Please donate 40€ to my PayPal account and you are allowed to use any
of my themes on one (1) commercial site.